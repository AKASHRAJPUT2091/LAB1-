package com.example.tourist_spot

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
